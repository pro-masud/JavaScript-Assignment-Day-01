
    // conform alert

    confirm("Hello Ami Masud Rana, Tumi Ki Ati korte Chaw, jodi korte chaw tahole Yes R Na Chaile No kore daw. Thank You Tomake");


    // Data output to Console log 
    
    console.log("Hello World");

    // console error output data

    console.error("Con't Not Access This Files");
    // 
    console.warn("Waring Message To Console")

    // prompt get user data 
    
    let user = prompt("Please Put Your Neme");
    let age = prompt("Put Your Age Now");

    console.log(`my Name is ${user} and I'm ${age} Years Old.`);